

import Project from "./component/Project";


function App() {
  return (
    
    <Project/>
   
   
    
  );
}

export default App;
